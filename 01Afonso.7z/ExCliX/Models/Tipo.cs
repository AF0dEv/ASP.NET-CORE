﻿namespace ExCliX.Models
{
    public class Tipo
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
    }
}
